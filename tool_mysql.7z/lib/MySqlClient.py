import os
import sys
import inspect
import logging


pathToAddToSys = \
[
    "../external",
]

for path in pathToAddToSys :
    cmd_subfolder = os.path.realpath(os.path.abspath(os.path.join(os.path.split(inspect.getfile( inspect.currentframe() ))[0], path)))
    if cmd_subfolder not in sys.path:
         sys.path.insert(0, cmd_subfolder)


import mysql.connector

# ----------------------------------------------------


class MysqlClient(object) :

    def __init__( \
        self, \
        host, \
        port, \
        user, \
        password, \
        database, \
        ) :

        self._host      = host
        self._port      = port
        self._user      = user
        self._password  = password
        self._database  = database

        self.dbConnection = None
        self.dbCursor     = None
        
        self.affectedRowNumber = -1 

        return


    def Initialize(self) :
        self.affectedRowNumber = -1
        self.dbConnection = mysql.connector.connect( \
            host        = self._host,       \
            port        = self._port,       \
            user        = self._user,       \
            passwd      = self._password,   \
            database    = self._database    \
            )

        self.dbCursor = self.dbConnection.cursor()

        return True

    def Release(self) :

        if self.dbCursor :
            self.dbCursor.close()
            self.dbCursor = None

        if self.dbConnection :
            self.dbConnection.close()
            self.dbConnection = None

        return True

    def ExecuteSqlCommandNoReturn(self, sqlCommandString, executeMulti = False) :
        try :
            self.dbCursor.execute(sqlCommandString, multi=executeMulti)
            self.dbConnection.commit()
            self.affectedRowNumber = self.dbCursor.rowcount
            return self.dbCursor.rowcount
        except:
            self.dbConnection.rollback()
            raise

    def ExecuteQuery(self, sqlCommandString) :
        self.dbCursor.execute(sqlCommandString)
        for dataRow in self.dbCursor:
            yield dataRow

    def GetLastStmtAffectedRowNumber(self):
        return self.affectedRowNumber

    def FetchQueryResultOneRow(self) :
        return self.dbCursor.fetchone()

    def GetQueryResultColumns(self) :
        return self.dbCursor.column_names

    def EscapeString(self, inputString) :
        return self.dbConnection.converter.escape(inputString)
