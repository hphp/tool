import os
import sys
import inspect
import logging


pathToAddToSys = \
[
    ".",
]

for path in pathToAddToSys :
    cmd_subfolder = os.path.realpath(os.path.abspath(os.path.join(os.path.split(inspect.getfile( inspect.currentframe() ))[0], path)))
    if cmd_subfolder not in sys.path:
         sys.path.insert(0, cmd_subfolder)


from MySqlClient import *

# ----------------------------------------------------


class MysqlConfig(object) :

    def __init__(self, partitionNumber, ip, port, userName, password, databaseName) :
        self._partitionNumber = partitionNumber
        self._ip              = ip
        self._port            = port
        self._userName        = userName
        self._password        = password
        self._databaseName    = databaseName
        return


# ----------------------------------------------------


class MySqlClusterClient(object) :

    def __init__(self, mysqlClusterConfig, dbidMysqlClusterConfig, dbid) :

        #
        # get mysql cluster config by dbid.
        #

        if dbid not in dbidMysqlClusterConfig :
            msg = 'Specified dbid is not registered in mysql cluster config. Dbid : {0}.\n'.format(dbid)
            msg += 'Registed dbid:\n'
            for _dbid, _clusterName in dbidMysqlClusterConfig.iteritems() :
                msg += '  - {0} : {1}\n'.format(_dbid, _clusterName)
            
            raise Exception(msg)

        clusterName = dbidMysqlClusterConfig[dbid]

        if clusterName not in mysqlClusterConfig :
            raise Exception('Specified cluster name has no mysql cluster config. Dbid : {0}, Cluster name: {1}.'.format(dbid, clusterName))

        clusterConfig = mysqlClusterConfig[clusterName]

        #
        # initialize mysql clients.
        #
        
        self._mysqlClientList = {}
        
        for mysqlConfig in clusterConfig :

            mysqlClient = MysqlClient( \
                mysqlConfig._ip,
                mysqlConfig._port,
                mysqlConfig._userName,
                mysqlConfig._password,
                mysqlConfig._databaseName
                )

            mysqlClient.Initialize()            
            self._mysqlClientList[mysqlConfig._partitionNumber] = mysqlClient

        return
    
    # ----------------------------------------------------

    def Release(self) :
        for mysqlClient in self._mysqlClientList.values() :
            mysqlClient.Release()
        return True

    # ----------------------------------------------------
    
    def GetNumberOfPartitions(self) :
        return len(self._mysqlClientList)

    # ----------------------------------------------------

    def ComputePartitionNumberFromInt(self, intPartitionKey) :
        partitionNumber = intPartitionKey % self.GetNumberOfPartitions()
        return partitionNumber

    # ----------------------------------------------------

    # BKDR string Hash, seed = 131
    def ComputePartitionNumberFromString(self, stringtPartitionKey) :

        if stringtPartitionKey == None :
            return 0

        stringHash = 0
        for char in stringtPartitionKey :
            stringHash = (stringHash * 131 + ord(char)) & 0xFFFFFFFFFFFFFFFF

        partitionNumber = stringHash % self.GetNumberOfPartitions()
        return partitionNumber

    # ----------------------------------------------------


    def ExecuteUpdate_SinglePartition(self, partitionNumber, sqlCommand) :

        sqlClient = self._mysqlClientList[partitionNumber]

        try :
            sqlClient.dbCursor.execute(sqlCommand, multi=False)
            sqlClient.dbConnection.commit()
            return sqlClient.dbCursor.rowcount

        except:
            sqlClient.dbConnection.rollback()
            raise

        return

    # ----------------------------------------------------

    def ExecuteQuery_SinglePartition(self, partitionNumber, sqlCommand) :

        sqlClient = self._mysqlClientList[partitionNumber]

        sqlClient.dbCursor.execute(sqlCommand)
        for dataRow in sqlClient.dbCursor:
            yield dataRow

        return

    # ----------------------------------------------------

    def ExecuteQuery_AllPartitions(self, sqlCommand) :

        for sqlClient in self._mysqlClientList.values() :
            sqlClient.dbCursor.execute(sqlCommand)
            for dataRow in sqlClient.dbCursor:
                yield dataRow

        return

    # ----------------------------------------------------

    def EscapeString(self, inputString) :
        firstMysqlClient = self._mysqlClientList.values()[0]
        return firstMysqlClient.EscapeString(inputString)

    # ----------------------------------------------------
    
    def ExecuteQuery_AllPartitions_NoReturn(self, sqlCommand) :

        for sqlClient in self._mysqlClientList.values() :
            sqlClient.dbCursor.execute(sqlCommand)

        return
