class UrlStatus(object) :

    Uploading      = 0
    Pending        = 1
    Processing     = 2
    Published      = 3
    Deleted        = 4
    Error          = 5
