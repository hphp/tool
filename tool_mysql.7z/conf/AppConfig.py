import os
import sys
import inspect
import logging


pathToAddToSys = \
[
    "..\lib",
]

for path in pathToAddToSys :
    cmd_subfolder = os.path.realpath(os.path.abspath(os.path.join(os.path.split(inspect.getfile( inspect.currentframe() ))[0], path)))
    if cmd_subfolder not in sys.path:
         sys.path.insert(0, cmd_subfolder)


from MySqlClusterClient import *


# -------------------------------------------------------------


class Dbid_List(object):

    # same
    Dbid_paipaile       = '1'
    Dbid_book           = '2'
    Dbid_poster         = '3'

    Dbid_experiments_same_haoyuan   = '3001'
    Dbid_experiments_same_haoyuan02 = '3002'

    # commercial
    Dbid_commercial_1   = '101'
    Dbid_commercial_2   = '102'


    # similar
    Dbid_similar_1001   = '1001'
    Dbid_similar_1002   = '1002'
    Dbid_similar_1003   = '1003'

    Dbid_same_tieba_01  = '1150'

    Dbid_CONTROLLER     = '1111'

# -------------------------------------------------------------


class AppConfig(object) :

    Environment = 'prod'     # prod, test


    CommercialDbidList = \
    [ 
        Dbid_List.Dbid_commercial_1,
        Dbid_List.Dbid_commercial_2
    ]

    # -------------------------------------------------------------
    # Data Collector

    MaxNumberOfPendingUrlToProcess = 5 * 1000 * 1000

    # -------------------------------------------------------------
    # Post Publish

    PostPublish_NumberOfHadoopNodes = 63
    
    # -------------------------------------------------------------
    # MySQL, Scheduler

    MySqlConfig_Scheduler       = MysqlConfig(0,  '10.23.241.203',     3306,   'mysql',    'MhxzKhl',      'visapp_indexgen')
    SchedulerMySqlTableName     = 'job_status'

    # -------------------------------------------------------------
    # MySQL, indexgen

    # cluster name -> cluster settings
    MysqlClusterConfig = \
    {
        'controller' :
        [
            MysqlConfig(0,  'tc-vis-same-bs22-1.tc.baidu.com',     3306,
                'root',    'root',      'visapp_indexgen'),
        ],

        'commercial' :
        [
            MysqlConfig(0,  '10.81.40.36',     3366,   'root',    'MhxzKhl',      'visapp_indexgen'),
            MysqlConfig(1,  '10.81.40.37',     3366,   'root',    'MhxzKhl',      'visapp_indexgen'),
        ],

        'same_book' :
        [
            MysqlConfig(0,  '10.26.29.24',     3366,   'root',    'MhxzKhl',      'visapp_indexgen'),
        ],
    }
    
    # dbid -> cluster name
    DbidMysqlClusterConfig = \
    {
        Dbid_List.Dbid_paipaile                       : 'shared',
        Dbid_List.Dbid_book                           : 'shared',
        Dbid_List.Dbid_poster                         : 'shared',
                
        #Dbid_List.Dbid_commercial_1                  : 'commercial',
        #Dbid_List.Dbid_commercial_2                  : 'commercial',

        Dbid_List.Dbid_similar_1001                   : 'shared',
        Dbid_List.Dbid_similar_1002                   : 'shared',
        Dbid_List.Dbid_similar_1003                   : 'shared',

        Dbid_List.Dbid_experiments_same_haoyuan       : 'shared',
        #Dbid_List.Dbid_experiments_same_haoyuan02    : 'ocean_dev',

        Dbid_List.Dbid_same_tieba_01                  : 'shared',

        Dbid_List.Dbid_CONTROLLER                     : 'controller',
    }


    TableName_Urls            = 'vis_indexgen_urls_02'
    TableName_ContentSigns    = 'vis_indexgen_contentsign_02'



    # -------------------------------------------------------------


    @staticmethod
    def Initialize() :
        return
