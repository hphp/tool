#include <bignum.h>
#include <bn_mul.h>
#include <config.h>
#include <md5c.h>
#include <rsa.h>
#include <stdio.h>
#include <string.h>

int main(int argn, char * argv[]){
    rsa_context rsa_license;
    unsigned char license[128] = "{\"pn\":\"com.baidu.idl.barcode\",\"sm\":\"2B51EA9585F5F58E778FA1F185C221D9\",\"al\":1,\"et\":1410257094,\"ak\":\"apikey1\"}";
    if(argn > 1){
        strcpy((char*)license, argv[1]);
        //printf("%s\n", license);
    }
    //memset(license, 0, sizeof(license));
    unsigned char decryptlicense[1024];
    unsigned char encryptlicense[1024];
    memset(decryptlicense, 0, sizeof(decryptlicense));
    memset(encryptlicense, 0, sizeof(encryptlicense));
    rsa_init(&rsa_license, RSA_PKCS_V15, 0);
    char n[] =
    "9E83ADC0EF1DA1189C7235D15C90F614D10A0AD1DC932941014AA699C15B83C66510DFB272D22F3978A8E8F9C61D08E78427F80A5768AFB75A684F6749611E198AC5F9E1E38FB89D6455A21A0922A1C4C7876CA12AF6B19B5EBB1721DD712BB113354A4B455E95CEC3FA07905E947A112E22955D5091D8FE16A28D8F2E2E03BB";
    char e[] = "010001";
    char d[] =
    "65F2BEBF858A82DFB74EE53A1FD4C3D02399D7D79D8BB04EB4ABF476931B6EA71CBD3B8223C2F6C879C7F8FF1BE1F4A622232AAE4C05726DF4617E2029DBA2653A3B7C1C33F626DD1F7088B227AF046F21DC2E5C93CF23CE4BEDA8D6C267F770624E9222C9CF0079653B021384912D60E935F8DF01E290594A43423F36D79051";

    mpi_read_string(&(rsa_license.N), 16, n);
    mpi_read_string(&(rsa_license.E), 16, e);
    mpi_read_string(&(rsa_license.D), 16, d);
    rsa_license.len = (mpi_msb(&rsa_license.N) + 7) >> 3;
    //printf("rsa_license.len : %d\n", rsa_license.len);
    rsa_public(&rsa_license, license, encryptlicense);
    rsa_private(&rsa_license, encryptlicense, decryptlicense);
    /*
    printf("decrypt:%s", decryptlicense);
        */
    printf("[");
    for(int i = 0 ;i < rsa_license.len ; i++){
        if(i>0)
            printf(" ,");
        printf("%d", encryptlicense[i]);
    }
    printf("]");
    return 0;
}
